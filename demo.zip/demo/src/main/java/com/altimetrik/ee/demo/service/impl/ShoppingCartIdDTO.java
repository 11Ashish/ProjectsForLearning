package com.altimetrik.ee.demo.service.impl;

import java.util.List;
public class ShoppingCartIdDTO {
    private List<Long> ids;

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }
}
