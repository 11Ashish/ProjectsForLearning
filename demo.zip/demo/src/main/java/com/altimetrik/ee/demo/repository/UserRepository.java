package com.altimetrik.ee.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.altimetrik.ee.demo.entity.User;


public interface UserRepository extends CrudRepository<User, Long> {
}
