package com.altimetrik.ee.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.altimetrik.ee.demo.entity.ShoppingCart;


public interface ShoppingCartRepository extends JpaRepository<ShoppingCart, Long> {
    List<ShoppingCart> findByStatus(String status);
}
