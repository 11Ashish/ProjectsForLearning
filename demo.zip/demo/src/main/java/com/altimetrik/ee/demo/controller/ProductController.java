package com.altimetrik.ee.demo.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.ee.demo.entity.Product;
import com.altimetrik.ee.demo.repository.ProductRepository;
import com.altimetrik.ee.demo.service.ProductService;


@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private ProductRepository productRepository;

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public List<Product> getAll(){
        return productService.findAll();
    }
   /* @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public List<Product> saveAll(){
        List<Product> l= productService.findAll();
    }*/
    public void saveInitialBatch(){
    	
        //productRepository.saveAll (products);
    }
    @GetMapping("/uniqueAndSorted")
    public Set<Product> removeDuplicateAndSort(){
      return  productService.removeDuplicateAndSortByPrice();
    }
}
