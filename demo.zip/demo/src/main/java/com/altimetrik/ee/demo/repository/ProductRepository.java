package com.altimetrik.ee.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.altimetrik.ee.demo.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Long> {

}
