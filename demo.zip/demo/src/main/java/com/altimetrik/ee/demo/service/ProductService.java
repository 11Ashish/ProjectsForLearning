package com.altimetrik.ee.demo.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.ee.demo.entity.Product;
import com.altimetrik.ee.demo.repository.ProductRepository;
@Service
@Transactional
public class ProductService{

    @Autowired
    private ProductRepository productRepository;

    private static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product(1l,35.75d,1000,"Pears baby soap for Kids","Soap"));
        products.add(new Product(2l,45.50d,500,"Signal Tooth Brushes Size in (L, M, S)","Tooth Brushe"));
        products.add(new Product(3l,1500.0d,100,"Casual Shirt imported from France","Shirt"));
        products.add(new Product(4l,1000.0d,400,"Leather bag imported from USA ","Office Bag"));
        products.add(new Product(5l,450.0d,800,"Hot Water Bottles","Bottle"));
        products.add(new Product(6l,2500.0d,800,"Imported wrist watches from swiss","Wrist Watch"));
        products.add(new Product(7l,45000.0d,800,"3G/4G capability","Mobile Phone"));
        products.add(new Product(8l,300.0d,800,"Head and Shoulders Shampoo","Shampoo"));
        products.add(new Product(9l,550.0d,800,"Imported Leather Wallets from AUS","Leather Wallets"));
        products.add(new Product(10l,85000.0d,800,"Imported Canon camera from USA","Camera"));
    }

    public void saveInitialBatch(){
        productRepository.saveAll( products);
    }

    public List<Product> findAll(){
        return productRepository.findAll();
    }

    public Set<Product> removeDuplicateAndSortByPrice(){
    	List<Product> l=productRepository.findAll();
    	
    	l.sort((Product p1,Product p2)->p1.getUnitPrice().intValue()-p2.getUnitPrice().intValue());
    	Set<Product> s=new LinkedHashSet<>(l);
    	return s;
    	
    }

}
